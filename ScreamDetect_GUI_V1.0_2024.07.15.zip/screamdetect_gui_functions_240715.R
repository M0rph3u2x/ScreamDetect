#-------------------------------------------------------------------------------
#Functions (BEGIN) -------------------------------------------------------------
#-------------------------------------------------------------------------------

#Start-Function-----------------------------------------------------------------

#Calculate call detection threshold based on reference calls
identify_ref_thres <- function(work_path,
                               ref.files,
                               ref_call,
                               filter,
                               lower_cut_off_freq,
                               higher_cut_off_freq,
                               loudness_threshold){
  
  #Create correct path to reference data
  ref.path <- paste(work_path, "reference_calls", sep = "/")
  
  #Get wav reference files
  ref.files <- list.files(ref.path, pattern = "\\.(wav|WAV)$")
  
  #Get wav/mp4 path
  ref.paths <- file.path(ref.path,ref.files)
  
  #Store threshold of each reference
  ref_thresholds <- data.frame(threshold=integer(),samplerate=integer())
  ref_threshold  <- ref_thresholds
  
  for(data_path in ref.paths){#data_path<-ref.paths[1]
    
    #Load audio file
    info     <- readWave(data_path, units="seconds", header = TRUE)
    duration <- info$samples/info$sample.rate
    audio    <- readWave(data_path, from=0, to=duration, units="seconds")
    
    #Band-Pass filter audio according to user settings (fir=seewave)
    if(filter=="on"){
      
      #Test frequency bandwidth to adapt low/highpass if necessary
      freq.test <- readWave(data_path, from=0, to=0.1, units="seconds") #Get test fragment of audio file
      freq.band <- spectro(freq.test,plot=FALSE)                       #Extract frequency bandwidth
      if(higher_cut_off_freq>floor(max(freq.band$freq))){                  #Reduce max bandpass filter if it is above the limit
        higher_cut_off_freq <- floor(max(freq.band$freq))
      }
      if(lower_cut_off_freq<floor(min(freq.band$freq))){                   #Increase min bandpass filter if it is below the limit
        lower_cut_off_freq <- floor(min(freq.band$freq))
      }
      
      #Apply low/high bandpass filters to audio data
      audio <- fir(audio, from=lower_cut_off_freq*1000, to=higher_cut_off_freq*1000, output="Wave")
    }
    
    #Amplitude data in db
    amp_data <- audio@left
    
    #Calculate threshold
    ref_thresholds[nrow(ref_thresholds)+1,] = c((max(amp_data)/100)*loudness_threshold,(info$sample.rate/1000))
  }
  
  #Get max/mean/min threshold depending on user setting
  for(kHz in unique(ref_thresholds$samplerate)){#kHz<-16
    if(ref_call == "max"){
      ref_threshold[nrow(ref_threshold)+1,] <- c(max(ref_thresholds$threshold[ref_thresholds$samplerate==kHz]),kHz) #Get max reference threshold
    }else if(ref_call == "mean"){
      ref_threshold[nrow(ref_threshold)+1,] <- c(mean(ref_thresholds$threshold[ref_thresholds$samplerate==kHz]),kHz) #Get mean reference threshold
    }else{
      ref_threshold[nrow(ref_threshold)+1,] <- c(min(ref_thresholds$threshold[ref_thresholds$samplerate==kHz]),kHz) #Get min reference threshold
    }
  }
  return(ref_threshold)
}

#End-Function-------------------------------------------------------------------

#Start-Function-----------------------------------------------------------------

#Load positive/negative filter templates for monitoR evaluation of detected calls
get_monitoR_templates <- function(work_path,lower_cut_off_freq=0,higher_cut_off_freq=0){
  
  #Get pig call filter locations -----------------------------------------------
  
  #Create correct path to noise folder:
  filter_path <- paste(work_path, "pattern_filter", "pos_filter", sep = "/")
  
  #Get path to pig call references (*.wav) 
  call_paths <- list.files(filter_path, pattern = "\\.(wav|WAV)$",full.names = TRUE)
  
  #-----------------------------------------------------------------------------
  
  #Check reference sample rate -------------------------------------------------
  sr <- c()
  for(path in call_paths){#path<-call_paths[1]
    
    #Get and save sample rate
    info             <- readWave(path, units="seconds", header = TRUE)
    sr[length(sr)+1] <- info$sample.rate/1000
  }
  
  #-----------------------------------------------------------------------------
  
  #Combine path and sample rate of filters in dataframe ------------------------
  
  filter_table <- data.frame(path=call_paths,samplerate=sr)
  
  #-----------------------------------------------------------------------------
  
  #Define monitoR Templates ----------------------------------------------------
  temp_sr <- list()
  for(sr in sort(unique(filter_table$samplerate))){#sr<-48
    call <- list()
    for(call_path in filter_table$path[filter_table$samplerate==sr]){#call_path<-"C:/Users/tjard/OneDrive/Desktop/PSD-Project/Pig_Scream_V5/Pig_Scream_Detector/pattern_filter/pos_filter/S20_48k_a.wav"
      name <- paste("p",length(call)+1,sep="")
      if(lower_cut_off_freq!=0 & higher_cut_off_freq!=0){
        call[length(call)+1] <- makeCorTemplate(call_path, name = name, frq.lim = c(lower_cut_off_freq, higher_cut_off_freq), score.cutoff = 0.5)
        #call[length(call)+1] <- makeBinTemplate(call_path, name = name, amp.cutoff = -40, frq.lim = c(lower_cut_off_freq, higher_cut_off_freq))
      }else{
        call[length(call)+1] <- makeCorTemplate(call_path, name = name, score.cutoff = 0.5)
        #call[length(call)+1] <- makeBinTemplate(call_path, name = name, amp.cutoff = -40)
      }
      #call[length(call)+1] <- makeBinTemplate(call_path, name = name)
    }
    temp_sr[[length(temp_sr)+1]] <- call
  }
  names(temp_sr) <- as.character(unique(filter_table$samplerate))
  
  #-----------------------------------------------------------------------------
  
  #Templates can be combined together in a single list with combineCorTemplates:
  
  #Feet call filter templates from list into variable "pos_temps"
  pos_temps_list <- list()
  for(call in temp_sr){
    for(i in 1:length(call)){
      if(i==1){#Add first template to variable "pos_temps"
        pos_temps <- combineCorTemplates(call[[i]])
        #pos_temps <- combineBinTemplates(call[[i]])
      }else{#Add remaining templates to variable "pos_temps"
        pos_temps <- combineCorTemplates(pos_temps,call[[i]])
        #pos_temps <- combineBinTemplates(pos_temps,call[[i]])
      }
    }
    pos_temps_list[[length(pos_temps_list)+1]] <- pos_temps
  }
  names(pos_temps_list) <- as.character(sort(unique(filter_table$samplerate)))
  
  #-----------------------------------------------------------------------------
  #-----------------------------------------------------------------------------
  
  #Get noise filter locations --------------------------------------------------
  
  #Create correct path to noise folder:
  filter_path <- paste(work_path, "pattern_filter", "neg_filter", sep = "/")
  
  #Get path to noise references (*.wav) 
  noise_paths <- list.files(filter_path, pattern = "\\.(wav|WAV)$",full.names = TRUE)
  
  #-----------------------------------------------------------------------------
  
  #Check reference sample rate -------------------------------------------------
  sr <- c()
  for(path in noise_paths){#path<-call_paths[1]
    
    #Get and save sample rate
    info             <- readWave(path, units="seconds", header = TRUE)
    sr[length(sr)+1] <- info$sample.rate/1000
  }
  
  #-----------------------------------------------------------------------------
  
  #Combine path and sample rate of filters in dataframe ------------------------
  
  filter_table <- data.frame(path=noise_paths,samplerate=sr)
  
  #-----------------------------------------------------------------------------
  
  #Define monitoR Templates ----------------------------------------------------
  temp_sr <- list()
  for(sr in sort(unique(filter_table$samplerate))){#sr<-16
    noise <- list()
    for(noise_path in filter_table$path[filter_table$samplerate==sr]){#noise_path<-noise_paths[1]
      name <- paste("n",length(noise)+1,sep="")
      if(lower_cut_off_freq!=0 & higher_cut_off_freq!=0){
        noise[length(noise)+1] <- makeCorTemplate(noise_path, name = name, frq.lim = c(lower_cut_off_freq, higher_cut_off_freq), score.cutoff = 0.5)
        #noise[length(noise)+1] <- makeBinTemplate(noise_path, name = name, amp.cutoff = -40, frq.lim = c(lower_cut_off_freq, higher_cut_off_freq))
      }else{
        noise[length(noise)+1] <- makeCorTemplate(noise_path, name = name, score.cutoff = 0.5)
        #noise[length(noise)+1] <- makeBinTemplate(noise_path, name = name, amp.cutoff = -40)
      }
      #noise[length(noise)+1] <- makeBinTemplate(noise_path , name = name)
    }
    temp_sr[[length(temp_sr)+1]] <- noise
  }
  names(temp_sr) <- as.character(sort(unique(filter_table$samplerate)))
  
  #-----------------------------------------------------------------------------
  
  #Templates can be combined together in a single list with combineCorTemplates:
  
  #Feet noise filter templates from list into variable "neg_temps"
  neg_temps_list <- list()
  for(noise in temp_sr){
    for(i in 1:length(noise)){
      if(i==1){#Add first template to variable "neg_temps"
        neg_temps <- combineCorTemplates(noise[[i]])
        #neg_temps <- combineBinTemplates(noise[[i]])
      }else{#Add remaining templates to variable "neg_temps"
        neg_temps <- combineCorTemplates(neg_temps,noise[[i]])
        #neg_temps <- combineBinTemplates(neg_temps,noise[[i]])
      }
    }
    neg_temps_list[[length(neg_temps_list)+1]] <- neg_temps
  }
  names(neg_temps_list) <- as.character(sort(unique(filter_table$samplerate)))
  
  #-----------------------------------------------------------------------------
  
  #Display cutoff values for each reference
  # templateCutoff(cor_temps)
  
  #-----------------------------------------------------------------------------
  
  #Change cutoff values
  #templateCutoff(cor_temps) <- c(TS4 = 0.5, TS5 = 0.5, TS6 = 0.5, TS8 = 0.5)
  
  #-----------------------------------------------------------------------------
  
  cor_temps <- list(pos_temps_list, neg_temps_list)
  
  return(cor_temps)
}

#End-Function-------------------------------------------------------------------

#Start-Function-----------------------------------------------------------------

mp4_to_wav_converter <- function(mp4_path){
  
  wav_path <- str_replace(mp4_path, ".mp4", ".wav")
  
  #Create call cutting command for ffmpeg (cmd line function)
  cmd <- paste("ffmpeg -i ",
               mp4_path,      #Input path + mp4 name
               " ",
               wav_path,  #Output path + mp4 name
               sep="")
  
  #Execute video cutting of selected call
  system(cmd)  
}

#End-Function-------------------------------------------------------------------

#Start-Function-----------------------------------------------------------------

#Identify pig screams that fit the parameters provided by the user
identify_pig_screams <- function(wav_path,
                                 filter,
                                 lower_cut_off_freq,
                                 higher_cut_off_freq,
                                 loudness_threshold,
                                 time_gap,
                                 call_dur,
                                 ref_switch,
                                 scream_threshold=NULL){
  
  #Load audio file
  info     <- readWave(wav_path, units="seconds", header = TRUE)
  duration <- info$samples/info$sample.rate
  audio    <- readWave(wav_path, from=0, to=duration, units="seconds")
  
  #Band-Pass filter audio according to user settings (fir=seewave)
  if(filter=="on"){
    
    #Test frequency bandwidth to adapt low/highpass if necessary
    freq.test <- readWave(wav_path, from=0, to=0.1, units="seconds") #Get test fragment of audio file
    freq.band <- spectro(freq.test,plot=FALSE)                       #Extract frequency bandwidth
    if(higher_cut_off_freq>floor(max(freq.band$freq))){                  #Reduce max bandpass filter if it is above the limit
      higher_cut_off_freq <- floor(max(freq.band$freq))
    }
    if(lower_cut_off_freq<floor(min(freq.band$freq))){                   #Increase min bandpass filter if it is below the limit
      lower_cut_off_freq <- floor(min(freq.band$freq))
    }
    
    #Apply low/high bandpass filters to audio data
    audio <- fir(audio, from=lower_cut_off_freq*1000, to=higher_cut_off_freq*1000, output="Wave")
  }
  
  #Amplitude data in db
  amp_data <- audio@left
  
  #Create time data in ms
  values_per_ms     <- info$sample.rate/1000 #db-values per ms in audio file
  sec_switch        <- 1
  samplerate_switch <- 1
  time_data         <- c()
  
  for(i in 1:length(amp_data)){
    time_data[i]      <- sec_switch
    samplerate_switch <- samplerate_switch+1
    if(samplerate_switch>values_per_ms){
      sec_switch <- sec_switch+1
      samplerate_switch <- 1
    }
  }
  
  #Create audio data table
  audio_table <- data.frame(amp_dB=amp_data,time_ms=time_data)
  
  if(ref_switch == "off"){
    #Calculate threshold
    scream_threshold <- (max(amp_data)/100)*loudness_threshold
    
    #Get positions where amplitude is above threshold
    db_above_thres <- audio_table[audio_table$amp_dB>scream_threshold,]
  }else{
    
    #Get samplerate of query video
    sr <- info$sample.rate/1000
    
    if(any(scream_threshold$samplerate==sr)==TRUE){ #Check if sample rate fits with reference
      #Get positions where amplitude is above threshold
      pos            <- audio_table$amp_dB>scream_threshold$threshold[scream_threshold$samplerate==sr]
      db_above_thres <- audio_table[pos,]
    }else{#If video samplerate is different than reference samplerate
      if(sr<min(scream_threshold$samplerate)){#Get lowest reference threshold
        #Get positions where amplitude is above threshold
        pos            <- audio_table$amp_dB>scream_threshold$threshold[min(scream_threshold$samplerate)==scream_threshold$samplerate]
        db_above_thres <- audio_table[pos,]
      }else if(sr>min(scream_threshold$samplerate)){#Get highest reference threshold
        #Get positions where amplitude is above threshold
        pos            <- audio_table$amp_dB>scream_threshold$threshold[max(scream_threshold$samplerate)==scream_threshold$samplerate]
        db_above_thres <- audio_table[pos,]
      }else{#Calculate mean reference threshold
        #Get positions where amplitude is above threshold
        pos            <- audio_table$amp_dB>mean(scream_threshold$threshold)
        db_above_thres <- audio_table[pos,]
      }
    }
  }
  
  #Sort "db_above_thres database" by time
  db_above_thres <- db_above_thres[order(db_above_thres$time_ms, db_above_thres$amp_dB),]
  #db_above_thres$Pos <- 1:length(db_above_thres$amp_dB)
  #Create on/offset data of detected screams
  onset      <- c() #Start time of call
  offset     <- c() #End time of call
  detections <- c() #Number of peaks above scream threshold
  call_id    <- 1   #On/offset event id
  
  #Get on/offset values
  for(i in 1:length(db_above_thres$amp_dB)){#i<-31
    if(i==1){ #Create first onset
      onset[call_id]      <- db_above_thres$time_ms[i]
      offset[call_id]     <- db_above_thres$time_ms[i]
      detection_counter   <- 1 #Number of observed peaks per call unit
      detections[call_id] <- detection_counter
    }
    if(i>1){ #Find time gap and create next on/offset pair
      timedif <- db_above_thres$time_ms[i]-db_above_thres$time_ms[i-1]
      if(timedif>time_gap){
        detection_counter   <- detection_counter+1
        detections[call_id] <- detection_counter
        offset[call_id]     <- db_above_thres$time_ms[i-1]
        call_id             <- call_id+1
        detection_counter   <- 1
        onset[call_id]      <- db_above_thres$time_ms[i]
        offset[call_id]     <- db_above_thres$time_ms[i]
        detections[call_id] <- detection_counter
      }else{
        offset[call_id]   <- db_above_thres$time_ms[i]
        detection_counter <- detection_counter+1
      }
    }
  }
  
  #Create on/offset table of detected screams
  pig_scream_table <- data.frame(Onset=onset,Offset=offset,Detections=detections)
  
  #Discard short intense noises based on minimal required call duration
  pig_scream_table <- pig_scream_table[(pig_scream_table$Offset-pig_scream_table$Onset)>call_dur,]
  
  #Delete NAs
  pig_scream_table <- na.omit(pig_scream_table)
  
  if(length(pig_scream_table$Onset) > 0 ){
    #Modify names
    names(pig_scream_table) <- c("Onset_ms","Offset_ms","Detections")
    
    #Check if calls have been detected
    #Format call on/offset if detected
    if(length(pig_scream_table$Onset)>0){
      
      #Add two columns seconds
      pig_scream_table$Onset_sec  <- pig_scream_table$Onset_ms /1000
      pig_scream_table$Offset_sec <- pig_scream_table$Offset_ms/1000
      
      #Add two columns minutes
      options(digits.secs = 3) #Show milliseconds when listing time
      pig_scream_table$Onset_min  <- format(as.POSIXct(Sys.Date(), tz="GMT")+pig_scream_table$Onset_sec , "%M:%OS")
      pig_scream_table$Offset_min <- format(as.POSIXct(Sys.Date(), tz="GMT")+pig_scream_table$Offset_sec, "%M:%OS")
      options(digits.secs = 0) #Set options back to original configuration
      
      #Add duration of detected calls
      pig_scream_table$Duration_ms <- pig_scream_table$Offset_ms-pig_scream_table$Onset_ms
    }
  }else{
    pig_scream_table <- data.frame(Onset=0,Offset=0,Detections=0)
  }
  
  #Rearrange order in dataframe
  if(sum(pig_scream_table[1,1:2])!=0){
    pig_scream_table <- pig_scream_table[,c(1,2,4,5,6,7,3,8)]    
  }else{
    pig_scream_table$Onset_sec   <- 0
    pig_scream_table$Offset_sec  <- 0 
    pig_scream_table$Onset_min   <- 0 
    pig_scream_table$Offset_min  <- 0
    pig_scream_table$Duration_ms <- 0
    pig_scream_table             <- pig_scream_table[,c(1,2,4,5,6,7,3,8)]
  }
  
  return(pig_scream_table)
}

#End-Function-------------------------------------------------------------------

#Start-Function-----------------------------------------------------------------

#Create video files of detected calls
create_mp4_of_calls <- function(pig_scream_table,
                                audio_ref_filter,
                                mp4_path,
                                mp4_name,
                                mp4_dur,
                                out.dir,
                                wav_dur,
                                cor_temps=NULL){
  
  #Exchange input with output path
  mp4_out <- file.path(out.dir, mp4_name)
  
  for (i in length(pig_scream_table$Onset_min):1) {#i<-35
    
    #Create call id label
    call_nr <- paste("_call_", i, ".mp4",sep="")
    
    #Switch ending of original file with call id
    this_mp4_out <- sub(".mp4$", call_nr, mp4_out)
    
    #Get duration of selected call event
    duration <- pig_scream_table$Offset_ms[i]-pig_scream_table$Onset_ms[i]
    
    #Check and edit time duration if smaller than required mp4 duration
    if(duration<mp4_dur){
      
      add_time <- (mp4_dur-duration)/2
      
      mod_start <- (pig_scream_table$Onset_ms[i] -add_time)/1000
      mod_end   <- (pig_scream_table$Offset_ms[i]+add_time)/1000
      
      #Check start time for validity and transform to "minutes:seconds:milliseconds"
      if(mod_start<0){
        begin <- 0
      }else{
        begin <- mod_start
      }
      
      #Convert time to day/hour/minute/seconds/milliseconds
      start_time <- convert_seconds_to_d_h_m_s_ms(begin)
      
      
      #Check end time for validity and transform to "hour:minutes:seconds:milliseconds"
      if(mod_end>wav_dur){
        
        #Convert time to day/hour/minute/seconds/milliseconds
        end_time  <- convert_seconds_to_d_h_m_s_ms(pig_scream_table$Offset_sec[i])
        
        #Convert time to day/hour/minute/seconds/milliseconds
        begin      <- (pig_scream_table$Onset_ms[i] -(mp4_dur-duration))/1000
        start_time <- convert_seconds_to_d_h_m_s_ms(begin)
      }else{
        #Convert time to day/hour/minute/seconds/milliseconds
        end      <- mod_end
        end_time <- convert_seconds_to_d_h_m_s_ms(end)
      }
    }else{
      start_time <- convert_seconds_to_d_h_m_s_ms(pig_scream_table$Onset_ms[i]/1000)
      end_time   <- convert_seconds_to_d_h_m_s_ms(pig_scream_table$Offset_ms[i]/1000)
    }
    
    #Create short control video from original mp4 -------------
    
    #Create call cutting command for ffmpeg (cmd line function)
    cmd <- paste("ffmpeg",
                 " -ss ",
                 start_time,    #Start time
                 " -to ",
                 end_time,      #Stop time
                 " -i ",
                 mp4_path,      #Path to mp4 file
                 " -c copy ",
                 this_mp4_out,  #Output path + mp4 name
                 sep="")
    
    #Execute video cutting of selected call
    system(cmd)
    
    if(audio_ref_filter=="on"){
      
      #Create short reference video from original mp4 -------------
      
      start_time <- format(as.POSIXct(Sys.Date(), tz="GMT")+((pig_scream_table$Onset_ms[i]-100)/1000), "%M:%OS")
      end_time   <- format(as.POSIXct(Sys.Date(), tz="GMT")+((pig_scream_table$Offset_ms[i]+2000)/1000), "%M:%OS")
      
      #Create call cutting command for ffmpeg (cmd line function)
      call_name <- paste("call_", i, ".wav",sep="")
      call_name <- sub(basename(mp4_out), call_name, mp4_out)
      
      cmd <- paste("ffmpeg",
                   " -ss ",
                   start_time,    #Start time
                   " -to ",
                   end_time,      #Stop time
                   " -i ",
                   mp4_path,      #Path to mp4 file
                   " ",
                   call_name,     #Output path + wav name
                   sep="")
      
      #Execute mp4 conversion to wav
      system(cmd)
      
      #Create picture of detected call  -------------
      
      hit_call <- readWave(call_name)
      windows() #Create plot in new window
      viewSpec(hit_call) # Show spectrogram
      this_png_out <- str_replace(call_name, ".wav",".png") 
      dev.copy(png,this_png_out)
      while (!is.null(dev.list()))  dev.off() #Save plot & close window
      
    }#End audio_ref_filter
  }#End call loop
}

#End-Function-------------------------------------------------------------------

#Start-Function-----------------------------------------------------------------

#Subfunction of "create_mp4_of_calls"
#Searches for matches between templates and detected calls
get_detections <- function(wav_path,cor_temps){
  
  #Calculate correlation score between the templates and each time bin in the detected call
  cor_scores <- corMatch(wav_path, cor_temps, time.source = "fileinfo")
  #cor_scores <- binMatch(wav_path, cor_temps, time.source = "fileinfo")
  
  #------------------------------------------------------------------------------------------------------------------------------
  
  #Identify "peaks" in the scores
  cor_peaks <- findPeaks(cor_scores)
  
  #------------------------------------------------------------------------------------------------------------------------------
  
  #Determine which, if any, score peaks exceed the score cutoff
  cor_detects <- getDetections(cor_peaks)
  
  return(cor_detects)
}

#End-Function-------------------------------------------------------------------

#Start-Function-----------------------------------------------------------------

#Source: https://stackoverflow.com/questions/27312292/convert-seconds-to-days-hoursminutesseconds

#Subfunction of "create_mp4_of_calls"
#Converts seconds into days/hours/minutes/seconds/milliseconds
convert_seconds_to_d_h_m_s_ms = function(x) {
  days    <- floor(x %/% (60 * 60 * 24))
  hours   <- floor((x - days*60*60*24) %/% (60 * 60))
  minutes <- floor((x - days*60*60*24 - hours*60*60) %/% 60)
  seconds <- floor(x - days*60*60*24 - hours*60*60 - minutes*60)
  ms      <- x - days*60*60*24 - hours*60*60 - minutes*60 - seconds
  ms      <- as.numeric(round(ms,4))
  ms      <- sub(pattern = ".*\\.(.*)$", replacement = "\\1", ms)
  days_str    <- ifelse((                                           days == 0), NA, paste0(days   ))
  hours_str   <- ifelse((                              hours == 0 & days == 0), NA, paste0(hours  ))
  minutes_str <- ifelse((               minutes == 0 & hours == 0 & days == 0), NA, paste0(minutes))
  seconds_str <- ifelse((seconds == 0 & minutes == 0 & hours == 0 & days == 0), NA, paste0(seconds))
  ms_str      <- ifelse((                                             ms == 0), NA, paste0(ms))
  time_str    <- paste(days_str, hours_str, minutes_str, seconds_str, sep=":")
  time_str    <- ifelse(ms_str == 0, time_str, paste(time_str, ms_str, sep="."))
  time_str    <- str_remove_all(time_str, "NA:")
  return(time_str)
}

#End-Function-------------------------------------------------------------------

#Start-Function-----------------------------------------------------------------

#Create an overview activity plot of the pig scream frequency
activity_plot <- function(input.path,scream_thres,filter_date,start_date=0,end_date=0){
  
  #Filter output path for xlsx files
  xlsx.files    <- fs::dir_ls(path = input.path, type = "file", glob = "*.xlsx", recurse = TRUE)
  
  #Load and rbind all xlsx data
  all_xlsx <- data.frame()
  for(file in xlsx.files){
    my_data <- read_excel(file)
    my_data$Filename <- basename(dirname(file))   #Extract name
    info <- strsplit(basename(dirname(file)), "-", fixed=T)      #Split string by symbol "-"
    my_data$Kamera    <- info[[1]][1]
    my_data$Date      <- info[[1]][2]
    my_data$Time      <- info[[1]][3]
    my_data$Hour      <- str_sub(info[[1]][3], start= 1,end=2)
    my_data$Frequency <- nrow(my_data)
    all_xlsx <- rbind(all_xlsx,my_data)
  }
  rm(my_data)
  
  #Filter data for user defined time window
  if(filter_date == "on"){
    date_list         <- all_xlsx$Date
    date_list         <- as.numeric(date_list)
    all_xlsx$Date_num <- date_list
    all_xlsx          <- subset(all_xlsx, Date_num >= start_date & Date_num <= end_date)
  }
  
  #-------------------------------------------------------------------------------
  
  #-------------------------------------------------------------------------------
  
  #Create Activity Plot for each Kamera
  cams <- unique(all_xlsx$Kamera)
  
  for (cam in cams){#cam<-cams[1]
    
    #Create Activity Plot for each Kamera
    cams <- unique(all_xlsx$Kamera)
    
    cam_data <- all_xlsx[all_xlsx$Kamera==cam,] #Extract data from a single camera
    #cam_data$Hour <- as.numeric(cam_data$Hour)  #Convert data from string to numeric
    #tidyverse
    #Working
    
    #Rotate date label if to more then 10 are plotted:
    if(length(unique(cam_data$Hour))>=100){
      ggplot(cam_data) +
        geom_bar(aes(x = Hour, group = Date, colour="Screams",fill="red"), show.legend = FALSE)+
        geom_hline(aes(yintercept=scream_thres,linetype ="dashed"), linewidth=2, color = "green", show.legend = FALSE)+ #Alarm threshold
        facet_grid(~Date, space="free_x", scales="free_x", switch="x") +
        theme(plot.title=element_text(margin=margin(t=40,b=-30),hjust = 0.5),
              strip.placement = "outside",
              strip.background = element_rect(fill=NA,colour="grey50"),
              strip.text.x = element_text(size=8, angle=90),
              axis.text.x  = element_text(color=c("transparent")),
              panel.grid.major.x = element_blank(),
              panel.grid.minor.x = element_blank(),
              panel.grid.minor.y = element_blank(),
              panel.spacing=unit(0,"cm")) +
        labs(title = cam,
             x = 'Time[Hours/Recording date]',
             y = 'Number of detected screams')
      name <- paste("output/",cam,".jpg",sep="")
      ggsave(name, dpi=300, width=8, height=4)  
    }else if(length(unique(cam_data$Hour))<100){
      ggplot(cam_data) +
        geom_bar(aes(x = Hour, group = Date, colour="Screams",fill="red"), show.legend = FALSE)+
        geom_hline(aes(yintercept=scream_thres,linetype ="dashed"), linewidth=2, color = "green", show.legend = FALSE)+ #Alarm threshold
        facet_grid(~Date, space="free_x", scales="free_x", switch="x") +
        theme(plot.title=element_text(margin=margin(t=40,b=-30),hjust = 0.5),
              strip.placement = "outside",
              strip.background = element_rect(fill=NA,colour="grey50"),
              strip.text.x = element_text(size=8, angle=90),
              axis.text.x  = element_text(size=6, angle=90),
              panel.grid.major.x = element_blank(),
              panel.grid.minor.x = element_blank(),
              panel.grid.minor.y = element_blank(),
              panel.spacing=unit(0,"cm")) +
        labs(title = cam,
             x = 'Time[Hours/Recording date]',
             y = 'Number of detected screams')
      name <- paste("output/",cam,".jpg",sep="")
      ggsave(name, dpi=300, width=8, height=4)  
    }
  }
}

#End-Function-------------------------------------------------------------------

#Start-Function-----------------------------------------------------------------

#Erase (user defined) all directories and content based on recording date
erase_data <- function(input_path,erase_date){#input_path<-out.path
  
  #Get paths with a specific folder name, find folder
  dir_list <- fs::dir_ls(path = input_path, type = "directory", regexp = "(Kamera*)", recurse = FALSE)
  
  #Extract dates (e.g. "20220323" [Year|Month|Day])
  extr_dates <- str_sub(dir_list, start= -26,end=-19)
  
  #Convert data from string to numeric
  extr_dates <- as.numeric(extr_dates)
  erase_date <- as.numeric(erase_date)
  #erase_date <- "20220324"
  
  #Find directories that should be deleted
  erase_pos <- extr_dates<erase_date
  
  #Erase dirctories
  unlink(dir_list[erase_pos], recursive=TRUE)
}

#End-Function-------------------------------------------------------------------
