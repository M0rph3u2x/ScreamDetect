#!/usr/bin/env Rscript --vanilla

# The script was written by Tjard Bergmann (2024) and is not licensed.
# Everyone is free to use or edit it under the rules of creative commons (CC BY-SA).

#-------------------------------------------------------------------------------

#-----------------------------
# Description
#-----------------------------

# This R-script is initiated by the TaskScheduler package and will initiate the
# pig scream detector in a time schedule defined in the parameter table.

#-----------------------------
# Software dependencies
#-----------------------------

#In order to run the Pig Scream Detector the following programming languages,
#editors, tools and software must be installed.

#Install Java (x64) [https://www.java.com/de/]
#Install R (x64)    [https://cran.r-project.org/]
#Install RStudio    [https://posit.co/]
#Install Rtools		  [https://cran.r-project.org/bin/windows/Rtools/rtools43/rtools.html]
#Install ffmpeg     [https://ffmpeg.org]
#Setup instructions for ffmpeg are described in (software->Install_ffmpeg.txt)

#-----------------------------
# Guide
#-----------------------------

# 1) To successfully run the "Run_PSD_Automatic_247.R" script adapt the 
#    directory on line 44 to your R script location path.

#-------------------------------------------------------------------------------

# 1) Specify directory ---------------------------------------------------------

# Set the working directory to the folder where the program is running
R.Directory <- "C:/Users/tjard/OneDrive/Desktop/Detector/"

#-------------------------------------------------------------------------------

# 2) Install/Load packages into RStudio ----------------------------------------

# Define package manager
packages <- c("pacman")

# Install package manager if not yet installed
installed_packages <- packages %in% rownames(installed.packages())
if (any(installed_packages == FALSE)) {
  install.packages(packages[!installed_packages])
}

#---------------------------

#Install and/or load all necessary packages via package manager "pacman"
pacman::p_load(ScreamDetect) #Load the ScreamDetect package

#-------------------------------------------------------------------------------

# 3) Setup directory where the program is running ------------------------------

setwd(R.Directory)

#-------------------------------------------------------------------------------

# 4) Run ScreamDetect (single run)
ScreamDetect(R.Directory)