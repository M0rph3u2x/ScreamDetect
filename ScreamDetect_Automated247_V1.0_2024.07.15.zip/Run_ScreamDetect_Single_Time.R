#!/usr/bin/env Rscript --vanilla

# The script was written by Tjard Bergmann (2024) and is not licensed.
# Everyone is free to use or edit it under the rules of creative commons (CC BY-SA).

#-------------------------------------------------------------------------------

#-----------------------------
# Description
#-----------------------------

# This R-script setups ScreamDetect to run a single time analyzing
# all video data available within the main folder or subdirectories. The main
# folder is the directory above the directory where this script and other R
# scripts are stored.

#-----------------------------
# Software dependencies
#-----------------------------

#In order to run the Pig Scream Detector the following programming languages,
#editors, tools and software must be installed.

#Install Java (x64) [https://www.java.com/de/]
#Install R (x64)    [https://cran.r-project.org/]
#Install RStudio    [https://posit.co/]
#Install Rtools		  [https://cran.r-project.org/bin/windows/Rtools/rtools43/rtools.html]
#Install ffmpeg     [https://ffmpeg.org]
#Setup instructions for ffmpeg are described in (software->Install_ffmpeg.txt)

#-----------------------------
# Guide
#-----------------------------

# To successfully install R packages on your computer you need to:

# 1) Press Ctr+A, then Ctrl+Enter to execute the program
#    (The script will automatically install all necessary packages)


#-------------------------------------------------------------------------------

# 2) Install/Load packages into RStudio ----------------------------------------

# Define package manager
packages <- c("pacman")

# Install package manager if not yet installed
installed_packages <- packages %in% rownames(installed.packages())
if (any(installed_packages == FALSE)) {
  install.packages(packages[!installed_packages])
}

#---------------------------

#Install and/or load all necessary packages via package manager "pacman"
pacman::p_load(ScreamDetect, #Load the pig scream detector package
               rstudioapi)   #function(getSourceEditorContext()$path): #Get path from RStudio

#-------------------------------------------------------------------------------

# 3) Setup directory where the program is running ------------------------------

#Create path to data
R.Directory = sub(pattern = "(.*/).*\\..*$", replacement = "\\1", getSourceEditorContext()$path)

# Set the working directory to the folder where the program is running
setwd(R.Directory)

#-------------------------------------------------------------------------------

# 4) Run the pig scream detector (single run)
ScreamDetect(R.Directory)