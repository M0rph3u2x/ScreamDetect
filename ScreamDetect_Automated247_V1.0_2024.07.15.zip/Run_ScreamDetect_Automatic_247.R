#!/usr/bin/env Rscript --vanilla

# The script was written by Tjard Bergmann (2024) and is not licensed.
# Everyone is free to use or edit it under the rules of creative commons (CC BY-SA).

#-------------------------------------------------------------------------------

#-----------------------------
# Description
#-----------------------------

# This R-script setups ScreamDetect to run in a user defined interval.
# The interval is regulated by the parameter table stored in the parameters folder. 

#-----------------------------
# Software dependencies
#-----------------------------

#In order to run ScreamDetect the following programming languages,
#editors, tools and software must be installed.

#Install Java (x64) [https://www.java.com/de/]
#Install R (x64)    [https://cran.r-project.org/]
#Install RStudio    [https://posit.co/]
#Install Rtools		  [https://cran.r-project.org/bin/windows/Rtools/rtools43/rtools.html]
#Install ffmpeg     [https://ffmpeg.org]
#Setup instructions for ffmpeg are described in (software->Install_ffmpeg.txt)

#-----------------------------
# Guide
#-----------------------------

# To successfully run the detector automatically in a user defined time interval:

# 1) Set the time interval parameters in the parameters table (2024-04-17_parameter.csv/xlsx) 
#    within the ""parameters" folder. The default setting is each day and every two hours.Read the
#    manual for a detailed description of the available parameters.

# 2) To successfully run this script open the script "Run_ScreamDetect.R" and
#    adapt the directory on line 41 to your R script location path.
#    (Save the "Run_ScreamDetect.R" file after adapting the path, this step
#    must only be performed once or after changing the location)

# 3) Press Ctr+A, then Ctrl+Enter to execute the program
#    (The script will automatically install all necessary packages)

#-------------------------------------------------------------------------------

# 2) Install/Load packages into RStudio ----------------------------------------

# Define package manager
packages <- c("pacman")

# Install package manager if not yet installed
installed_packages <- packages %in% rownames(installed.packages())
if (any(installed_packages == FALSE)) {
  install.packages(packages[!installed_packages])
}

#---------------------------

#Install and/or load all necessary packages via package manager "pacman"
pacman::p_load(ScreamDetect, #Load ScreamDetect package
               rstudioapi)   #function(getSourceEditorContext()$path): #Get path from RStudio

#-------------------------------------------------------------------------------

# 3) Setup directory where the program is running ------------------------------

#Create path to data
R.Directory = sub(pattern = "(.*/).*\\..*$", replacement = "\\1", getSourceEditorContext()$path)

# Set the working directory to the folder where the program is running
setwd(R.Directory)

#-------------------------------------------------------------------------------

# 4) Run ScreamDetect (automatic 247 loop)
task_scheduler_screamdetect(R.Directory,"Run_ScreamDetect.R")
