#!/usr/bin/env Rscript --vanilla

# The script was written by Tjard Bergmann (2024) and is not licensed.
# Everyone is free to use or edit it under the rules of creative commons (CC BY-SA).

#-------------------------------------------------------------------------------

#-----------------------------
# Description
#-----------------------------

# This R-script installs and sets up all mandatory R packages
# which are needed in order to properly run ScreamDetect.

#-----------------------------
# Software dependencies
#-----------------------------

#In order to run ScreamDetect the following programming languages,
#editors, tools and software must be installed.

#Install Java (x64) [https://www.java.com/de/]
#Install R (x64)    [https://cran.r-project.org/]
#Install RStudio    [https://posit.co/]
#Install Rtools		  [https://cran.r-project.org/bin/windows/Rtools/rtools43/rtools.html]
#Install ffmpeg     [https://ffmpeg.org]
#Setup instructions for ffmpeg are described in (software->Install_ffmpeg.txt)

#-----------------------------
# Guide
#-----------------------------

# To successfully install all necessary R packages on your computer you need to:

# 1) Press Ctr+A, then Ctrl+Enter to execute the program
#    (The script will automatically install all necessary packages)

#-------------------------------------------------------------------------------

# 2) Install/Load packages into RStudio ----------------------------------------

# Define package manager
packages <- c("pacman")

# Install package manager if not yet installed
installed_packages <- packages %in% rownames(installed.packages())
if (any(installed_packages == FALSE)) {
  install.packages(packages[!installed_packages])
}

#---------------------------

# Define package email client manager
packages <- c("devtools","RDCOMClient")

# Install package manager if not yet installed
installed_packages <- packages %in% rownames(installed.packages())
if (any(installed_packages == FALSE)) {
  if(installed_packages[1] == FALSE){
    install.packages("devtools")
    library("devtools")
    install_github('omegahat/RDCOMClient')
  }else{
    library("devtools")
    install_github('omegahat/RDCOMClient')
  }
}

#---------------------------

#Install and/or load all necessary packages via package manager "pacman"
pacman::p_load(base,              #functions(list.files,sub,file.path,dir.create,print,paste0,format,as.POSIX,Sys.Date,options,dput,dget): Basic data processing functions
               fs,                #functions(fs::dir_ls): Find and list files of a specific type (faster than list.files)
               monitoR,           #functions(makeCorTemplate,combineCorTemplates,corMatch,findPeaks,getDetections,viewSpec): Filter false positive call detections
               seewave,           #functions(spectro, fir): Audiodata analysis
               stringr,           #functions(str_replace)
               TAF,               #function(rmdir): Remove empty folders in output directory
               taskscheduleR,     #functions(taskscheduler_create, taskscheduler_delete):Set time schedule for automated pig scream detection
               tuneR,             #function(readWave): Audiodata analysis
               readxl,            #function(read_excel): Reads excel files
               RDCOMClient,       #function(COMCreate): Send outlook email messages
               rstudioapi,        #function(getSourceEditorContext()$path): #Get path from RStudio
               xlsx)              #function(write.xlsx): Data export to xlsx file

#-------------------------------------------------------------------------------

# 3) Setup directory where the program is running ------------------------------

#Create path to data
R.Directory = sub(pattern = "(.*/).*\\..*$", replacement = "\\1", getSourceEditorContext()$path)

#Create shortcut to main path (Fullpath connects R.directory with follow up folders)
FullPath = function(FileName){ return( paste(R.Directory,FileName,sep="") ) }

# Set the working directory to the folder where the program is running
setwd(R.Directory)

#Submit working directory to variable
work_path <- getwd()

#-------------------------------------------------------------------------------

# 4) Install ScreamDetect package ----------------------------------------------

# 4a) Install detector via package (offline)

# Define package name
package <- c("ScreamDetect")

# Install ScreamDetect package if not yet installed
installed_packages <- package %in% rownames(installed.packages())
if (any(installed_packages == FALSE)) {
  ScreamDetect_package <- fs::dir_ls("ScreamDetect_package", recurse = TRUE, glob = "*.tar.gz")
  install.packages(FullPath(ScreamDetect_package[length(ScreamDetect_package)]), repos = NULL, type="source")
}

# 4b) Install detector with github (online)

# Install/Load package manager if not yet installed
if (any(installed_packages == FALSE)) {
  if(installed_packages[1] == FALSE){
    install.packages("devtools")
    library("devtools")
    install_github('M0rph3u2x/ScreamDetect')
  }else{
    library("devtools")
    install_github('M0rph3u2x/ScreamDetect')
  }
}

#-------------------------------------------------------------------------------