library(shiny)
library(bslib)
library(shinycssloaders)

#Starting configuration
config.files <- list.files(FullPath("settings"), pattern = "\\config.csv$")
path.config  <- file.path(FullPath("settings"), max(config.files))
if(file.exists(path.config)){
  def.config <- dget(file=path.config)
}else{
  def.config <- list("on","mean",70,2000,10,6000,"on",c(1,4),"off",5,"on","off","20220323","20220327","no","20220323")
}

## Only run examples in interactive R sessions
if (interactive()) {

  ui <- page_fillable(

    tags$head(
      tags$style(HTML("
        #Setup detector parameters {
          font-weight: bold;  # Fetter Text
        }
        #Save1 {
          color: black;  # Textfarbe
        }
        #Save1:hover {
          color: red;  # Textfarbe beim Hover
        }
        #submit1:hover {
          color: red;  # Textfarbe beim Hover
        }
        #Save2:hover {
          color: red;  # Textfarbe beim Hover
        }
        #submit2:hover {
          color: red;  # Textfarbe beim Hover
        }
      "))
    ),

    layout_columns(
      fill = FALSE, #FALSE = Layout is fixed; TRUE = Layout can grow/shrink
      card(
        titlePanel(h1("Setup detector parameters")),
        style = "background-color: #d9ead3;", #Green
        align = "center"
      ),
      card(
        actionButton("Save1"  , "Save settings"    ,style = "background-color: #ffffff;"),
        actionButton("submit1", "Confirm selection",style = "background-color: #ffffff;"),
        style = "background-color: #cccccc;" #Grey
      ),
      card(
        titlePanel("Main settings"),
        radioButtons("refcall", "Use reference calls:",
                     choiceNames = list(
                       "On",
                       "Off"
                     ),
                     choiceValues = list(
                       "on",
                       "off"
                     ),
                     selected = def.config[[1]]),
        conditionalPanel(
          condition = "input.refcall == 'on'",
          radioButtons("reftype", "Reference focus [dB]:",
                       choiceNames = list(
                         "Loudest reference",
                         "Mean reference",
                         "Quietest reference"
                       ),
                       choiceValues = list(
                         "max",
                         "mean",
                         "min"
                       ),
                       selected = def.config[[2]])
        ),
        numericInput("loudness_threshold",
                     "Loudness threshold (%):",
                     value = def.config[[3]]),
        numericInput("time_gap",
                     "Time gap between calls (ms):",
                     value = def.config[[4]]),
        numericInput("call_dur",
                     "Minimal call duration (ms):",
                     value = def.config[[5]]),
        numericInput("mp4_dur",
                     "Minimum duration of detected call video (ms):",
                     value = def.config[[6]]),
        radioButtons("bandpass", "Band-Pass Filter",
                     choiceNames = list(
                       "On",
                       "Off"
                     ),
                     choiceValues = list(
                       "on",
                       "off"
                     ),
                     selected = def.config[[7]]),
        conditionalPanel(
          condition = "input.bandpass == 'on'",
          sliderInput("range", "Band-Pass Filter (kHz):",
                      min = 0.1, max = 100,
                      value = c(def.config[[8]][1],def.config[[8]][2]))
        ),
        style = "background-color: #fff2cc;" #Yellow
      ),
      card(
        titlePanel("Optional settings"),
        radioButtons("makeRefs", "Create audio reference filter",
                     choiceNames = list(
                       "On",
                       "Off"
                     ),
                     choiceValues = list(
                       "on",
                       "off"
                     ),
                     selected = def.config[[9]]),
        numericInput("scream_thres",
                     "Number of screams needed to get a warning:",
                     value = def.config[[10]]),
        radioButtons("act_switch", "Create activity plot:",
                     choiceNames = list(
                       "On",
                       "Off"
                     ),
                     choiceValues = list(
                       "on",
                       "off"
                     ),
                     selected = def.config[[11]]),
        conditionalPanel(
          condition = "input.act_switch == 'on'",
          radioButtons("filter_date", "Filter activity for a specific time period:",
                       choiceNames = list(
                         "On",
                         "Off"
                       ),
                       choiceValues = list(
                         "on",
                         "off"
                       ),
                       selected = def.config[[12]]),
          conditionalPanel(
            condition = "input.filter_date == 'on'",
            textInput("start_date",
                      "Enter beginning date [year|month|day](e.g. 20220323)",
                      value = def.config[[13]]),
            textInput("end_date",
                      "Enter end date [year|month|day](e.g. 20220327)",
                      value = def.config[[14]])
          ),
        ),
        radioButtons("erase_data", "Erase older detector results (clean harddrive space):",
                     choiceNames = list(
                       "Yes",
                       "No"
                     ),
                     choiceValues = list(
                       "yes",
                       "no"
                     ),
                     selected = def.config[[15]]),
        conditionalPanel(
          condition = "input.erase_data == 'yes'",
          textInput("erase_date",
                    "Erase recording date [year|month|day](e.g. 20220323 -> deletes everything before the 23. March 2022):",
                    value = def.config[[16]])
        ),
        style = "background-color: #b4a7d6;" #Purple
      ),
      card(
        actionButton("Save2"  , "Save settings"    ,style = "background-color: #ffffff;"),
        actionButton("submit2", "Confirm selection",style = "background-color: #ffffff;"),
        style = "background-color: #cccccc;" #Grey
      ),
      col_widths  = c(12,12,6,6,12),
      row_heights = c(0.7,1,6,6,1)
    )
  )

  server <- function(input, output, session) {

    observeEvent(input$Save1, { # Save configuration incl. current date
      showNotification("Setting saved", type = "warning")
      save.config <- list(input$refcall,
                          input$reftype,
                          input$loudness_threshold,
                          input$time_gap,
                          input$call_dur,
                          input$mp4_dur,
                          input$bandpass,
                          input$range,
                          input$makeRefs,
                          input$scream_thres,
                          input$act_switch,
                          input$filter_date,
                          input$start_date,
                          input$end_date,
                          input$erase_data,
                          input$erase_date)
      date        <- paste(Sys.Date(),"_config.csv", sep="")
      path.config <- file.path(FullPath("settings"), date)
      dput(save.config,path.config)
    })

    observeEvent(input$Save2, { # Save configuration incl. current date
      showNotification("Setting saved", type = "warning")
      save.config <- list(input$refcall,
                          input$reftype,
                          input$loudness_threshold,
                          input$time_gap,
                          input$call_dur,
                          input$mp4_dur,
                          input$bandpass,
                          input$range,
                          input$makeRefs,
                          input$scream_thres,
                          input$act_switch,
                          input$filter_date,
                          input$start_date,
                          input$end_date,
                          input$erase_data,
                          input$erase_date)
      date        <- paste(Sys.Date(),"_config.csv", sep="")
      path.config <- file.path(FullPath("settings"), date)
      dput(save.config,path.config)
    })

    observe({
      if (input$submit1 == 0 & input$submit2 == 0)
        return()

      parameters <- list(input$refcall,
                         input$reftype,
                         input$loudness_threshold,
                         input$time_gap,
                         input$call_dur,
                         input$mp4_dur,
                         input$bandpass,
                         input$range,
                         input$makeRefs,
                         input$scream_thres,
                         input$act_switch,
                         input$filter_date,
                         input$start_date,
                         input$end_date,
                         input$erase_data,
                         input$erase_date)
      stopApp(parameters)
    })
  }

  shinyApp(ui, server)
}
