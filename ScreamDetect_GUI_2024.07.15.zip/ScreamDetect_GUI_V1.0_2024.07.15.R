#!/usr/bin/env Rscript --vanilla

# The script was written by Tjard Bergmann (2024) and is not licensed.
# Everyone is free to use or edit it under the rules of creative commons (CC BY).

#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------

#-----------------------------
# Description
#-----------------------------

#ScreamDetect-GUI-Version - 15 July 2024

# This R-script identifies calls above a user defined loudness threshold.
# Optionally the user can define a threshold for minimal call distances
# based on this value detected calls above threshold will be separated into
# different on/offset events.
# The user can also define Bandpass filters to reduce noise or focus on a
# specific kHz spectrum of interest.
# The R-script will create a table listing the on and offset location of identified
# calls (milliseconds, seconds, minutes).
# The script was developed to identify pig screams (related to tail biting) within
# pig barn recordings (*.mp4).

#-----------------------------
# Software dependencies
#-----------------------------

#All software packages are stored in the
#software folder

#Install Java (x64) [https://www.java.com/de/]
#Install R (x64)    [https://cran.r-project.org/]
#Install RStudio    [https://www.rstudio.com/]
#Install ffmpeg     [https://ffmpeg.org]
#Setup instructions for ffmpeg are described in (software->Install_ffmpeg.txt)

#-----------------------------
# Guide
#-----------------------------
# The program will analyze video files in *.mp4 format. Multiple files can be analyzed
# in succession if stored in the "input" folder. An output folder with the detected calls
# will be created by the program when it is run.

# Warning: The total path to the R script should not include empty spaces in the path:

# False  : C:\Users\tjard\OneDrive\Desktop\ScreamDetect GUI Folder
# Correct: C:\Users\tjard\OneDrive\Desktop\ScreamDetect_GUI_Folder

# To successfully run the program you need to:

# 1) Add at least one "mp4" file into the input folder. The name of the wave file will be the reference
#    for creating the output (e.g. Kamera1-20220323-004113-1647992473.mp4 -> "Kamera1-20220323-004113-1647992473")

# 2) Press Ctr+A, then Ctrl+Enter to execute the program

# 3) Adapt parameters in GUI according to your needs

#-------------------------------------------------------------------------------

# 1) Install/Load packages into RStudio -------------------------------------------------

# Define package manager
packages <- c("pacman")

# Install package manager if not yet installed
installed_packages <- packages %in% rownames(installed.packages())
if (any(installed_packages == FALSE)) {
  install.packages(packages[!installed_packages])
}

#---------------------------

#Install and/or load all necessary packages via package manager "pacman"
pacman::p_load(base,              #functions(list.files,sub,file.path,dir.create,print,paste0,format,as.POSIX,Sys.Date,options,dput,dget): Basic data processing functions
               fs,                #functions(fs::dir_ls): Find and list files of a specific type (faster than list.files)
               ggplot2,           #functions(ggplot2): Create Elegant Data Visualisations
               monitoR,           #functions(viewSpec): Filter false positive call detections
               readxl,            #functions(readxl): Read Excel Files
               seewave,           #functions(spectro, fir): Audiodata analysis
               shiny,             #functions(runApp): Create GUI for data management
               shinycssloaders,   #functions(runApp): Create GUI for data management
               stringr,           #functions(str_replace)
               TAF,               #function(rmdir): Remove empty folders in output directory
               tuneR,             #function(readWave): Audiodata analysis
               rstudioapi,        #function(getSourceEditorContext()$path): Get path from RStudio
               xlsx)              #function(write.xlsx): Data export to xlsx file

#-------------------------------------------------------------------------------

# 2) Create input/output path for R-Script -------------------------------------

#Create path to data
R.Directory = sub(pattern = "(.*/).*\\..*$", replacement = "\\1", getSourceEditorContext()$path)

#Path shortcut function
FullPath = function(FileName){ return( paste(R.Directory,FileName,sep="") ) }

# Set the working directory to the folder where the data for the F0 analysis are
setwd(R.Directory)
work_path <- getwd()

#Create correct path to input data -----------------------------
input.path <- paste(work_path, "input", sep = "/")

# Setup directory where data output is stored ------------------

#Create main output folder
out.path <- FullPath("output")
dir.create(out.path, showWarnings = FALSE)

#-------------------------------------------------------------------------------

# 3) Load all necessary functions into the script ------------------------------

source(FullPath("screamdetect_gui_functions_240715.R"))

#-------------------------------------------------------------------------------

# 4) Define program parameters -------------------------------------------------

#Manual or automatic data analysis
parameters <- runApp(FullPath("shiny/program_parameters_240715.R"))

#Reference calls switch
#If "TRUE" threshold parameters will be generated based on
#the reference audio files
ref_switch <- parameters[[1]]     #Use of reference: "On" or "Off"

#Reference focus (can be on quiet, mean or loudest reference call [dB])
ref_call <- parameters[[2]]

#Loudness threshold (%) - Only calls above threshold are listed (amplitude is measured)
loudness_threshold <-parameters[[3]]

#Time_gap_parameter (Defines minimal gap time between two measurements above threshold)
#Important to calculate on/offset values
time_gap <- parameters[[4]]

#Call_duration_parameter (Defines minimal call duration)
#Important to calculate minimal required call duration (filters out intense short noises)
call_dur <- parameters[[5]]

#Get the minimal length each call video must have
mp4_dur <- parameters[[6]]

#Band-Pass filter (kHz)
filter              <- parameters[[7]]     #Filter "On" or "Off"
lower_cut_off_freq  <- parameters[[8]][1] #Delete audio frequency below frequency threshold
higher_cut_off_freq <- parameters[[8]][2] #Delete audio frequency above frequency threshold

#Create audio reference filter (on/off)
audio_ref_filter <- parameters[[9]]

#Scream threshold:
scream_thres <- parameters[[10]]

#Create activity plot (on/off)
act_switch <- parameters[[11]]

#Create activity plot for a specific time period
filter_date <- parameters[[12]]

#Start activity plot from:
start_date  <- parameters[[13]]

#End activity plot at:
end_date    <- parameters[[14]]

#Switch for erasing data (yes/no)
erase_data <- parameters[[15]]

#Erasing date (all datafiles before the date are deleted)
erase_date <- parameters[[16]]

#Free space
rm(parameters)

#-------------------------------------------------------------------------------

# 5) Get Input mp4 -------------------------------------------------------------

print("Get input videos")

#Get mp4 input files
mp4.files <- list.files(input.path, pattern = "*.mp4")

#Get mp4 absolute path
mp4.paths <- file.path(input.path,list.files(input.path, pattern = "*.mp4"))

#Delete ending and extract unique names from dataset
file_names <- sub(pattern = "(.*)\\..*$", replacement = "\\1", mp4.files)

#-------------------------------------------------------------------------------

# Optional) Create reference scream threshold ----------------------------------

#Get reference data (if activated)
if(ref_switch == "on"){

  #Identify loudness threshold of reference calls
  scream_threshold   <- identify_ref_thres(work_path,
                                           ref.files,
                                           ref_call,
                                           filter,
                                           lower_cut_off_freq,
                                           higher_cut_off_freq,
                                           loudness_threshold)
}

#-------------------------------------------------------------------------------

# 6) Scan videos for pig screams -----------------------------------------------

if(length(mp4.files)>=1){#Control if recordings are detected
  for(dataset.nr in 1:length(mp4.files)){#dataset.nr<-3

    # 6A) Extract audio data from mp4 file -------------------------------------

    #Create wav from mp4
    mp4_to_wav_converter(mp4.paths[dataset.nr])

    #Get wav input file path
    wav_path <- str_replace(mp4.paths[dataset.nr], ".mp4", ".wav")

    #---------------------------------------------------------------------------

    #Create data specific output folder
    out.dir <- file.path(out.path,file_names[dataset.nr])
    dir.create(out.dir, showWarnings = FALSE)

    # 6B) Identify calls above threshold ---------------------------------------

    #Identify pig screams that fit the parameters provided by the user
    pig_scream_table <- identify_pig_screams(wav_path,
                                             filter,
                                             lower_cut_off_freq,
                                             higher_cut_off_freq,
                                             loudness_threshold,
                                             time_gap,
                                             call_dur,
                                             ref_switch,
                                             scream_threshold)

    #Delete wav files from hard drive
    #Check its existence
    if (file.exists(wav_path)) {

      #Check input duration
      info    <- readWave(wav_path, units="seconds", header = TRUE)
      wav_dur <- info$samples/info$sample.rate

      #Delete file if it exists
      file.remove(wav_path)
    }


    #Go to next dataset if no scream has been detected
    if(sum(pig_scream_table[1,1:2])==0){
      print(paste0("Continue with next file: ", file_names[dataset.nr+1]))
      next
    }

    #---------------------------------------------------------------------------

    # 6C) Create video files of detected calls ----------------------------------

    #Check if calls have been detected
    #Format call on/offset if detected
    if(length(pig_scream_table$Onset_ms)>0){
        create_mp4_of_calls(pig_scream_table,
                            audio_ref_filter,
                            mp4.paths[dataset.nr],
                            mp4.files[dataset.nr],
                            mp4_dur,
                            out.dir,
                            wav_dur)
    }

    #---------------------------------------------------------------------------

    # 7) Create overview table -------------------------------------------------

    #Create xlsx summary table (contains on/offsets of detected calls)
    xlsx.table.name  <- "Pig_call_table.xlsx"
    table.path       <- file.path(out.dir, xlsx.table.name)
    write.xlsx(pig_scream_table,table.path,row.names=FALSE)

    #---------------------------------------------------------------------------

    #Write feeddback info about the next selected dataset
    if(dataset.nr<length(mp4.files)){
      print(paste0("Continue with next file: ", file_names[dataset.nr+1]))
    }
  }
}


#Remove empty folders of files without detected screams
#Dependent on package(TAF)
rmdir(out.path, recursive = TRUE)

#-------------------------------------------------------------------------------

#Create activity plot (if activated) -------------------------------------------
if(act_switch == "on"){

  #Filter data for user defined time period
  if(filter_date == "on"){
    activity_plot(out.path,scream_thres,filter_date,start_date,end_date)
  }else{
    activity_plot(out.path,scream_thres,filter_date)
  }
}

#-------------------------------------------------------------------------------

#Erase old data ----------------------------------------------------------------

#Filter data for user defined time period
if(erase_data == "yes"){
  erase_data(out.path,erase_date)
}

#-------------------------------------------------------------------------------

#-------------------------------------------------------------------------------
 print("Finished processing the data!")
#-------------------------------------------------------------------------------
